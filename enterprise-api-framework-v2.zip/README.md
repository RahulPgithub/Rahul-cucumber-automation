
# Enterprise API Framework v2

Features:
- Cucumber + TestNG
- Config support
- Jenkins ready

Run:
mvn clean test
