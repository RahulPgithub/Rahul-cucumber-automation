
package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
 static Properties prop;

 public static void load(){
  try{
   prop=new Properties();
   prop.load(new FileInputStream("src/test/resources/config/qa.properties"));
  }catch(Exception e){e.printStackTrace();}
 }

 public static String get(String key){
  return prop.getProperty(key);
 }
}
