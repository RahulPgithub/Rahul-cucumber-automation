
package base;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class BaseAPI {

 public Response get(String url){
  return RestAssured.get(url);
 }
}
