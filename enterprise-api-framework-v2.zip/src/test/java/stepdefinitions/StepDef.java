
package stepdefinitions;

import io.cucumber.java.en.*;
import io.restassured.response.Response;
import utils.ConfigReader;
import base.BaseAPI;

import static org.testng.Assert.*;

public class StepDef {

 Response res;
 BaseAPI api=new BaseAPI();

 @Given("load config")
 public void load(){
  ConfigReader.load();
 }

 @When("hit API")
 public void hit(){
  String url = ConfigReader.get("base.url") + "/posts/1";
  res = api.get(url);
 }

 @Then("validate response")
 public void validate(){
  assertEquals(res.getStatusCode(),200);
 }
}
