
Feature: Execute APIs

Scenario: Run API
 Given load config
 When hit API
 Then validate response
